"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useLocale } from "next-intl";
import { useEffect, useState } from "react";
import { routing } from "@/i18n/routing";

// LOGO_LIGHT sits on dark backgrounds (e.g. the home hero image).
// LOGO_DARK sits on light backgrounds (every other section/page).
// Drop the two files in public/images/logo/.
const LOGO_LIGHT = "/images/logo/logo-white.svg";
const LOGO_DARK = "/images/logo/logo-black.svg";

export function Logo() {
  const pathname = usePathname();
  const locale = useLocale();
  const [overDark, setOverDark] = useState(false);

  const segments = pathname.split("/").filter(Boolean);
  const isHome =
    segments.length === 1 &&
    (routing.locales as readonly string[]).includes(segments[0]);

  useEffect(() => {
    if (!isHome) {
      setOverDark(false);
      return;
    }

    // Sections can opt in with data-logo-bg="dark" (e.g. the hero image).
    // While that section is in view under the fixed logo, use the light
    // mark; everywhere else, use the dark mark.
    const target = document.querySelector('[data-logo-bg="dark"]');
    if (!target) {
      setOverDark(false);
      return;
    }

    setOverDark(true); // it's the first section, so start true to avoid a flash

    const observer = new IntersectionObserver(
      ([entry]) => setOverDark(entry.isIntersecting),
      { threshold: 0.4 }
    );
    observer.observe(target);
    return () => observer.disconnect();
  }, [isHome, pathname]);

  const src = overDark ? LOGO_LIGHT : LOGO_DARK;

  return (
    <Link
      href={`/${locale}`}
      className="fixed top-8 left-1/2 -translate-x-1/2 z-40 block"
      aria-label="OrCompare — home"
    >
      <Image
        src={src}
        alt="OrCompare"
        width={120}
        height={40}
        priority
        className="h-16 w-auto"
      />
    </Link>
  );
}